import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, catchError,retry, throwError } from 'rxjs';
import { BookingHistory } from '../models/booking-history.model';
import { Chat } from '../models/chat.model';

@Injectable({
  providedIn: 'root'
})
export class HttpDataService {

  baseUrl = 'http://localhost:3000/api/v1';

  constructor(private http: HttpClient) { }

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
    })
  }

  // Error handling
  handleError(error: HttpErrorResponse) {
    if(error.error instanceof ErrorEvent) {
      console.log(`An error occurred: '${error.status}, body was: ${error.error}'`);
    } else {
      console.log(`Backend returned code ${error.status}, body was: ${error.error}`);
    }
    return throwError('Something happened with request, try again.');
  }

  // Get all booking history
  getAllBookingHistory(): Observable<BookingHistory> {
    return this.http.get<BookingHistory>(`${this.baseUrl}/bookingHistory`)
      .pipe(retry(2),catchError(this.handleError))
  }

  // Get all messages 
  getItems(): Observable<Chat> {
    return this.http.get<Chat>(`${this.baseUrl}/chat`)
      .pipe(retry(2),catchError(this.handleError))
  }
  
  //createMessage
  createItem(item:any): Observable<Chat>{
    return this.http.post<Chat>(`${this.baseUrl}/chat`, JSON.stringify(item), this.httpOptions)
    .pipe(retry(2),catchError(this.handleError))
  }


}
