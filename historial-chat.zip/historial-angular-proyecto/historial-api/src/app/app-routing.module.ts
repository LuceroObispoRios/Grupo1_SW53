import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

//Componentes agregados
import { HistoryCardsComponent } from './components/history-cards/history-cards.component';
import { MainPageComponent } from './components/main-page/main-page.component';


const routes: Routes = [
  { path: '', redirectTo: '/booking-history', pathMatch: 'full' },
  { path: 'booking-history', component: HistoryCardsComponent },
  { path: 'main-page', component: MainPageComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
