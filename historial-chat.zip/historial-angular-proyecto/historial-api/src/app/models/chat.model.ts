export interface Chat {
    id: any;
    message: any;
    dateTime: any;
}