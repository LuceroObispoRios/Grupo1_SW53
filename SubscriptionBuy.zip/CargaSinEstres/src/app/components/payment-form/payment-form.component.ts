import { Component } from '@angular/core';

@Component({
  selector: 'app-payment-form',
  templateUrl: './payment-form.component.html',
  styleUrls: ['./payment-form.component.css']
})
export class PaymentFormComponent {
  nombre: string = '';
  apellidos: string = '';
  ruc: string = '';
  direccion: string = '';
  vigenciaSuscripcion: string = '';
  tarjetaSeleccionada: string = '';
  
  confirmacionVisible: boolean = false;
  
  firma: string = '©CargaSinEstres';

  onSubmit() {
    if (this.validarDatos()) {
      this.confirmacionVisible = true;
    }
  }

  generarCodigoAleatorio(): string {
    const caracteres = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let codigo = '';
    const longitudCodigo = 6;

    for (let i = 0; i < longitudCodigo; i++) {
      const indice = Math.floor(Math.random() * caracteres.length);
      codigo += caracteres.charAt(indice);
    }

    return codigo;
  }

  firmar() {
    this.firma = this.generarCodigoAleatorio();
  }

  validarDatos(): boolean {
    if (!this.nombre || !this.apellidos || !this.ruc || !this.direccion || !this.vigenciaSuscripcion || !this.tarjetaSeleccionada) {
      return false;
    }

    if (!/^\d{11}$/.test(this.ruc)) return false;
  
    return true;
  }
}
