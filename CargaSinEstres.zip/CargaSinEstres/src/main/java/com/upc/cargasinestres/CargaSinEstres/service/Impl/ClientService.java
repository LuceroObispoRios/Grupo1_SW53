package com.upc.cargasinestres.CargaSinEstres.service.Impl;


import com.upc.cargasinestres.CargaSinEstres.model.Client;
import com.upc.cargasinestres.CargaSinEstres.service.IClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ClientService implements IClientService{

    @Autowired
    private IClientService clientService;

    @Override
    public Client getClientsForLogin(String email, String password) {
        return clientService.getClientsForLogin(email, password);
    }

    @Override
    public Client getClientById(int id) {
        return clientService.getClientById(id);
    }

    @Override
    public Client createClient(Client client) {
        return clientService.createClient(client);
    }

    @Override
    public Client updateClient(int id, Client client) {
        return clientService.updateClient(id, client);
    }

}
