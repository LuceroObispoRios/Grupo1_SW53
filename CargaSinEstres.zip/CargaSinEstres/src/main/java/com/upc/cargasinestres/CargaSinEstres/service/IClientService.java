package com.upc.cargasinestres.CargaSinEstres.service;

import com.upc.cargasinestres.CargaSinEstres.model.Client;

public interface IClientService {

    //GET
    public abstract Client getClientsForLogin(String email, String password);

    public abstract Client getClientById(int id);


    //CREATE
    public abstract Client createClient(Client client);


    //UPDATE
    public abstract Client updateClient(int id, Client client);

}
