package com.upc.cargasinestres.CargaSinEstres.service;

import com.upc.cargasinestres.CargaSinEstres.model.BookingHistory;

public interface IBookingHistoryService {

    public abstract BookingHistory createReservation(BookingHistory bookingHistory);
}
