package com.upc.cargasinestres.CargaSinEstres.repository;

import com.upc.cargasinestres.CargaSinEstres.model.BookingHistory;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface IBookingHistoryRepository extends JpaRepository<BookingHistory, Long>{

    List<BookingHistory> findByClientId(String ClientId);

    List<BookingHistory> findByCompanyId(String CompanyId);

    Boolean existsByPickupAdressAndDestinationAdress(String pickupAdress, String destinationAdress);


}
