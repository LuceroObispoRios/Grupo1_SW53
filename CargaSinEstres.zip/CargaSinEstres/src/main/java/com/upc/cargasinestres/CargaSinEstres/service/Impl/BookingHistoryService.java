package com.upc.cargasinestres.CargaSinEstres.service.Impl;


import com.upc.cargasinestres.CargaSinEstres.model.BookingHistory;
import com.upc.cargasinestres.CargaSinEstres.service.IBookingHistoryService;
import org.springframework.beans.factory.annotation.Autowired;

public class BookingHistoryService implements IBookingHistoryService {

    @Autowired
    private IBookingHistoryService bookingHistoryService;

    @Override
    public BookingHistory createReservation(BookingHistory bookingHistory) {
        return bookingHistoryService.createReservation(bookingHistory);
    }
}
